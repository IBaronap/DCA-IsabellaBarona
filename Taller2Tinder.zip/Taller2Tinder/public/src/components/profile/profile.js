class MyProfile extends HTMLElement
{
    static get observedAttributes(){
        return ['name', 'age', 'km', 'description'];
    }

    constructor(){
        super();
        this.attachShadow({ mode : 'open' });
    }

    connectedCallback(){
        this.render();
    }

    attributeChangedCallback(propName, oldValue, newValue){
        this[propName] = newValue;
        this.render
    }

    render(){
        this.shadowRoot.innerHTML = `
        <link rel="stylesheet" href="/src/components/profile/style.css">
        <section>
            <div class="header">
                <img class="headerIcon" src="./src/components/counter/imgs/settings.png">
                <img class="logo" src="./src/components/counter/imgs/logo.png">
                <img class="headerIcon" src="./src/components/counter/imgs/chat.png">
            </div>
            <img class="pic" src="./src/components/counter/imgs/pic.png"
            <div class="info">
                <p><b>${this.name}</b>, ${this.age}</p>
                <p>${this.km} km away</p>
                <p>${this.description}</p>
            </div>
        </section>
        `;
    }
}

customElements.define('my-profile', MyProfile);
export default MyProfile;