import * as components from './components/index.js';

class AppContainer extends HTMLElement{
    constructor(){
        super();
        this.attachShadow({mode : 'open'});
    }

    connectedCallback() {
        this.render();
    }

    render(){
        this.shadowRoot.innerHTML = `
        <my-profile name="John Doe" age="21" km="12" description="Hi, this is a description"></my-profile>
        `;
    }
}

customElements.define('app-container', AppContainer);

class CountContainer extends AppContainer{

    render(){
        this.shadowRoot.innerHTML = `
        <link rel="stylesheet" href="/src/components/profile/style.css">
        <div class="CC">
            <my-counter></my-counter>
            <img class="icon" src="./src/components/counter/imgs/star.jpg">
            <my-counter2></my-counter2>
        </div>
        `;
    }
}

customElements.define('counter-container', CountContainer);