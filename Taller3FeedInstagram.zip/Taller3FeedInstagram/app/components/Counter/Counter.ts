
class MyCounter extends HTMLElement{
    count: number = 666;
    button: HTMLElement;

    

    constructor(){
        super();
        var heart = document.getElementById('heart');

        this.attachShadow({mode: "open"});
        this.button = this.ownerDocument.createElement("img");
        this.button.setAttribute('src', "./app/components/Profile/Imgs/heart_red.png")
        this.button.className = "other";
        this.button.id = "heart";
        this.button.addEventListener("click",this.handleClick);

    }

    handleClick= () =>{
        this.count ++;
        this.render();
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if(this.shadowRoot){
            this.shadowRoot.innerHTML = `
            <section>
            <link href="./app/components/Profile/style.css" rel="stylesheet">
            <div id="Down">
                <div>
                    <img class="other" id="heart" src="./app/components/Profile/Imgs/heart_red.png">
                    <img class="other" src="./app/components/Profile/Imgs/comment.png">
                    <img class="other" src="./app/components/Profile/Imgs/share.png">
                </div>
                <img class="swipe" src="./app/components/Profile/Imgs/swipe.jpg">
                <img class="other" id="bookmark" src="./app/components/Profile/Imgs/bookmark.png">
            </div>
            <b>${this.count} likes</b>
            </section>
            `;
            this.shadowRoot.appendChild(this.button);
        }
    }

}

customElements.define("my-counter",MyCounter);
export default MyCounter;