const Listas = require('./Funcion4');

const lista1 = ['borrador', 'lapiz', 'carboncillo', 'micropunta']
const lista2 = ['acrilico', 'borrador', 'lienzo', 'borrador', 'pincel', 'lapiz']
 
const comun = lista1.filter(x => lista2.indexOf(x) !== -1)
 

test('Repetidos', () => {
    expect(comun).toEqual(["borrador", "lapiz"]);
    console.log(comun);
})
