const Contenedor = require('./Funcion5');

const arr1 = ['rock', 'punk', 'rock alternativo', 'punk rock', 'rock metal']
const arr2 = ['rock alternativo', 'punk rock', 'rock metal']

const Incluye = arr1.some(x=> arr2.includes(x))

test('Incluye', () => {
    expect(Incluye).toEqual(true);
    console.log(Incluye)
})
