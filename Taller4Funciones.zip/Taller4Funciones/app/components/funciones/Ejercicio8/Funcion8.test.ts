const Good = require('./Funcion8');

var Ideas = ["Mala", "Buena", "Buena","Mala", "Mala"];

var contar = 0;
var start = 0;

let mensaje = "";

while ((start = Ideas.indexOf("Buena", start) + 1) > 0) {
    contar++;
}   if(contar === 0){mensaje = "Fallo"}
    if(contar === 1 || contar === 2){mensaje = "Publicar"}
    if(contar > 2){mensaje = "Fantastico"}

test('La idea es', () => {
    expect(mensaje).toEqual("Publicar");
    console.log(mensaje)
})
