"use strict";
/**
 * ejercicio 1
 * cree una función que recibe 2 arreglos como parametros.
 * luego combina estos arreglos en uno solo, alternando sus valores.
 *
 * ejem: dados los arreglos ["h", "a", "c"] y [7, 4, 17, 10, 48],
 * la respuesta deber ser: ["h", 7, "a", 4, "c", 17, 10, 48]
 *
 * note que los arreglos pueden ser de diferente tamaños y el contenido puede ser cualquier tipo de dato
 */
function Funcion1() {
    const array1 = ['Rojo', 'Azul', 'Verde', 'Blanco', 'Negro', 'Morado', 'Amarillo'];
    const array2 = ['Chocolate', 'Vainilla', 'Fresa', 'Brownie'];
    let [l, s] = array1.length > array2.length ? [array1, array2] : [array2, array1];
    const array3 = Array.from({ length: l.length * 2 }).map((_, i) => i % 2 == 0 ? l[i / 2] : s[Math.ceil(i / 2) - 1]).filter(el => el);
    console.log(array3);
    return array3;
}
module.exports = Funcion1;
