"use strict";
const combine = require('./Funcion1');
const array1 = ['Rojo', 'Azul', 'Verde', 'Blanco', 'Negro', 'Morado', 'Amarillo'];
const array2 = ['Chocolate', 'Vainilla', 'Fresa', 'Brownie'];
let [l, s] = array1.length > array2.length ? [array1, array2] : [array2, array1];
const array3 = Array.from({ length: l.length * 2 }).map((_, i) => i % 2 == 0 ? l[i / 2] : s[Math.ceil(i / 2) - 1]).filter(el => el);
test('Combinar arrays', () => {
    expect(array3).toEqual(['Rojo', 'Chocolate', 'Azul', 'Vainilla', 'Verde', 'Fresa', 'Blanco', 'Brownie', 'Negro', 'Morado', 'Amarillo']);
    console.log(array3);
});
