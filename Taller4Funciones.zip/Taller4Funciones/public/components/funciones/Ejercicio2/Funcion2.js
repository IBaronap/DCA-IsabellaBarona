"use strict";
/**
 * Ejercicio 2
 * Dado un arreglo de numeros, devuelva un arreglo con dos listas en su interios,
 * la primera contendrá los números pares del arreglo y la segunda los impares
 */
function Funcion2() {
    const numeros = [21, 69, 420, 421, 616, 666, 999];
    const pares = numeros.filter(x => x % 2 === 0);
    const impares = numeros.filter(x => x % 2 !== 0);
    const filtrado = [pares, impares];
    console.log(filtrado);
    return filtrado;
}
module.exports = Funcion2;
