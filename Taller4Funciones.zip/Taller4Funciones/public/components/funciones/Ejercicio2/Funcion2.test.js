"use strict";
const parimpar = require('./Funcion2');
const numeros = [21, 69, 420, 421, 616, 666, 999];
const pares = numeros.filter(x => x % 2 === 0);
const impares = numeros.filter(x => x % 2 !== 0);
const filtrado = [pares, impares];
test('pares', () => {
    expect(pares).toEqual([420, 616, 666]);
    console.log(pares);
});
test('impares', () => {
    expect(impares).toEqual([21, 69, 421, 999]);
    console.log(pares);
});
test('filtrado', () => {
    expect(filtrado).toEqual([[420, 616, 666], [21, 69, 421, 999]]);
    console.log(filtrado);
});
