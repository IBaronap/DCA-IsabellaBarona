"use strict";
/**
 * Ejercicio 3
 * dado un arreglo multidimensional compuesto por varios grupos de 3 letras.
 * ordene su contenido en orden alfabetico.
 *  * las letras de cada grupo están en orden aleatorio.
 *  * cada grupo de letras tambien tiene orden aleatorio en la lista multidimensional.
 *
 * Ejem:
 * dados los grupos de letras ["e", "d", "f"], ["a", "c", "b"], ["m", "o", "n"] en ese mismo orden
 * el resultado de la función debe ser ["a", "b", "c"], ["d", "e", "f"], ["m", "n", "o"] en ese mismo orden
 */
function Funcion3() {
    const letras = [["d", "c", "a"], ["m", "v", "s"], ["i", "b", "p"]];
    const grupo1 = letras[0].sort();
    const grupo2 = letras[1].sort();
    const grupo3 = letras[2].sort();
    const todos = [grupo1, grupo2, grupo3];
    const ordenado = todos.sort();
    console.log(ordenado);
    return ordenado;
}
module.exports = Funcion3;
