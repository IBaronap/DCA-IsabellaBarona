"use strict";
const Gupos = require('./Funcion3');
const letras = [["d", "c", "a"], ["m", "v", "s"], ["i", "b", "p"]];
const grupo1 = letras[0].sort();
const grupo2 = letras[1].sort();
const grupo3 = letras[2].sort();
const todos = [grupo1, grupo2, grupo3];
const ordenado = todos.sort();
test('Ordenar grupos', () => {
    expect(ordenado).toEqual([["a", "c", "d"], ["b", "i", "p"], ["m", "s", "v"]]);
    console.log(ordenado);
});
