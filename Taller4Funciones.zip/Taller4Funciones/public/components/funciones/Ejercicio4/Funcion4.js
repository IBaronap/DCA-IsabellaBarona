"use strict";
/**
 * Ejercicio 4
 * dadas dos listas de palabras, retorne una unica lista en la cual se encuentren las palabras
 * que existan en las dos listas iniciales,
 *
 * además ordene esta última lista de manera que las
 * palabras repetidas más veces en ambos arreglos se encuentren al inicio de la lista.
 *
 * ejem:
 * ["rat", "dog", "cat", "parrot", "cat"] y ["cat", "lizard", "rat", "cat"] devolverán ["cat", "rat"]
 */
function Funcion4() {
    const lista1 = ['borrador', 'lapiz', 'carboncillo', 'micropunta'];
    const lista2 = ['acrilico', 'borrador', 'lienzo', 'borrador', 'pincel', 'lapiz'];
    const comun = lista1.filter(x => lista2.indexOf(x) !== -1);
    console.log(comun);
    return comun;
}
module.exports = Funcion4;
