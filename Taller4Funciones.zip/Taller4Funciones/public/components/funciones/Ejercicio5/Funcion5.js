"use strict";
/**
 * Ejercicio 5
 * cree una función que reciba dos arreglos y verifique que el primero contenga todos los elementos del segundo
 */
function Funcion5() {
    const array1 = ['rock', 'punk', 'rock alternativo', 'punk rock', 'rock metal'];
    const array2 = ['rock alternativo', 'punk rock', 'rock metal'];
    const Incluye = arr1.some(r => arr2.includes(r));
    console.log(Incluye);
    return Incluye;
}
module.exports = Funcion5;
