export interface Attribute {
    personaje: string;
    apodo: string;
    estudianteDeHogwarts: string;
    casaDeHogwarts: string;
    interpretado_por: string;
    imagen: string;
}
