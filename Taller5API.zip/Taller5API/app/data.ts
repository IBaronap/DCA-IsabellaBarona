import {Attribute} from "./components/Profile/Profile"


export const getData = async (): Promise<Array<Attribute>> => {
      const response = await fetch("https://fedeperin-harry-potter-api.herokuapp.com/personajes/");
      const data = await response.json();
      console.log(data);
      return data;
};