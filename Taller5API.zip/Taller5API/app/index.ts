import {getData} from "./data.js"
import {Attribute} from "./components/Profile/Profile.js";

class AppContainer extends HTMLElement{

    constructor(){
        super();
        this.attachShadow({mode: "open"});
    }

    async connectedCallback() {
        const data = await getData ();
        this.render(data);
    }

     render(data: Array<Attribute>) {
        if(!this.shadowRoot) return;

        const personajes = data.map(
            ({personaje, apodo, estudianteDeHogwarts, casaDeHogwarts, interpretado_por, imagen}) => `<article>
        <link rel="stylesheet" href="./app/components/Profile/style.css">
             <section class="card">
                <img class="Personaje" src="${imagen}">
                <section class="Info">
                    <h2>${personaje}</h2>
                    <h3>Casa: ${casaDeHogwarts}</h3>  
                    <p><b>¿Es/Fue ${apodo} estudiante?</b> ${estudianteDeHogwarts}</p>
                    <p>Fue interpretado por ${interpretado_por}</p>
                </section>
             </section>
        </article>`);
        this.shadowRoot.innerHTML = `<section>
            ${personajes.join("")}
        </section>`;
        }}

customElements.define("app-container",AppContainer)