export enum SBAttribute {
    "username"="username",
    "profilepic" = "profilepic"
}

class MyRecomend extends HTMLElement{
    username?: string;
    profilepic?: string;

    static get observedAttributes(){
        const attrs: Record<SBAttribute,null> = {
            username: null,
            profilepic: null,
        };
        return Object.keys(attrs);
    }

    constructor(){
        super();
        this.attachShadow({mode: 'open'});
    }

    connectedCallback(){
        this.render();
    }

    attributeChangedCallback(
        propName: SBAttribute,
        oldValue: string | undefined,
        newValue: string | undefined,
        ){
            switch (propName) {
                default:
                    this[propName] = newValue;
                    break;
            }

            this.render();
    }

    render(){
        if(this.shadowRoot){
            this.shadowRoot.innerHTML = `
            <link href="./components/Home/style.css" rel="stylesheet">
            <section class="Recomendation">
                    <img class="PP" ${this.profilepic}
                    <div>
                        <h4 class="username">${this.username}</h4>
                        <p class="New">New in Instagram</p>
                    </div>
                    <p class="Follow"><t>Follow</t></p>
            </section>
            `
        }
    }
}

customElements.define("my-sidebar", MyRecomend);
export default MyRecomend;