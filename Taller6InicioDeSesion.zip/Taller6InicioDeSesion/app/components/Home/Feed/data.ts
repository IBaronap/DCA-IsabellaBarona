interface DataShape {
  username: string;
  ubication: string;
  profilepic: string;
  post: string;
  likes: number;
  caption: {
    usercomment: string;
    hashtag: string;
  };
  numbercomments: number;
  date: string;
}

const data: DataShape[] = [
  {
      "username": "MBposTIng",
      "ubication": "Hell",
      "profilepic": "<img src=https://www.asexuality.org/en/uploads/monthly_2020_07/b44799c6e975f90daff2d0c5f4014f84.thumb.jpg.539594dba6f0eefedb1827589cc2e9f2.jpg>",
      "post": "<img src=https://i.pinimg.com/736x/22/c6/a3/22c6a3a993ac23e986605727d79c7360.jpg>",
      "likes": 421,
      "caption": {
          "usercomment": "Lil' muffin",
          "hashtag": "#mbti #intj"
      },
      "numbercomments": 914,
      "date": "1 week ago"
  },
  {
      "username": "mekatsme",
      "ubication": " ",
      "profilepic": "<img src=https://i.pinimg.com/236x/8f/4a/61/8f4a61b00e4cc1c31929077fbb7b1364.jpg>",
      "post": "<img src=https://i.kym-cdn.com/photos/images/original/002/379/410/b97>",
      "likes": 421,
      "caption": {
          "usercomment": "Evil Hehe Cat",
          "hashtag": "#hehecat"
      },
      "numbercomments": 96,
      "date": "5 years ago"
  },
  {
      "username": "Coffeedrunk",
      "ubication": "Lviv, Ukraine",
      "profilepic": "<img src=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0V0SmvTJFqtv0oDE0VhAuL-WNlkJaP8gMyA&usqp=CAU>",
      "post": "<img src=https://i.pinimg.com/originals/b4/ac/6c/b4ac6cef9c19cb03fbb2423a01047fb8.jpg>",
      "likes": 421,
      "caption": {
          "usercomment": "Coffee feast!",
          "hashtag": "#cofeeaddict #latteart #coffeelife #coffeeculture"
      },
      "numbercomments": 7,
      "date": "1 Oct 2022"
  },
  {
      "username": "travel_beast",
      "ubication": "Cairo, Egypt",
      "profilepic": "<img src=https://burst.shopifycdn.com/photos/in-flight-over-mountains.jpg?width=1200&format=pjpg&exif=1&iptc=1>",
      "post": "<img src=https://i.insider.com/5c3ccc17630d9b7d3874db52?width=700>",
      "likes": 421,
      "caption": {
          "usercomment": "Closer to the pharaoh...",
          "hashtag": "#travel #cairo #giza"
      },
      "numbercomments": 6,
      "date": "30 Mar 2022"
  },
  {
      "username": "pokestop",
      "ubication": "sponsored",
      "profilepic": "<img src=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSh_fzIhGZd7bWjTMd-CRjb7hh8cpO5f_DadQ&usqp=CAU>",
      "post": "<img src=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTruOgOccPvoVkTFH04eiXonOKvqQD1-fZkuw&usqp=CAU>",
      "likes": 421,
      "caption": {
          "usercomment": "New acquisition",
          "hashtag": "#nintendo #nintendouk #pokemon #videogame"
      },
      "numbercomments": 23,
      "date": "3 days ago"
  },
  {
      "username": "Jasper_Ghost",
      "ubication": "San Diego",
      "profilepic": "<img src=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbzw12RWiw1KO4ekacAvxAeX2ms-oxvBu9pQ&usqp=CAU>",
      "post": "<img src=https://i.pinimg.com/736x/da/25/2e/da252e76757c930d381c035be776cf62.jpg>",
      "likes": 421,
      "caption": {
          "usercomment": "Amazing pic taken at yesterday's concert",
          "hashtag": "#heavymetal #metalhead #guitarcover"
      },
      "numbercomments": 16,
      "date": "1 day ago"
  },
  {
      "username": "Inkye",
      "ubication": " ",
      "profilepic": "<img src=https://static.boredpanda.com/blog/wp-content/uploads/2019/12/10-5de84f415ebf5__700.jpg>",
      "post": "<img src=https://pbs.twimg.com/media/FBSi_ZdXMAUFnKz.jpg>",
      "likes": 421,
      "caption": {
          "usercomment": "Inktober day #9 Pressure",
          "hashtag": "#inkart #inktober #ink"
      },
      "numbercomments": 10,
      "date": "9 Oct 2021"
  },
  {
      "username": "AwakeSheep",
      "ubication": "Texas",
      "profilepic": "<img src=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBWmmN3i42P2vj5jz_GivIpVDMuk8dJb6HzA&usqp=CAU>",
      "post": "<img src=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSB9nLcUvxBqaUaSrazlC_KPJba3TmSIHJwLQ&usqp=CAU>",
      "likes": 421,
      "caption": {
          "usercomment": "Don't trust!!",
          "hashtag": "#debate #theory"
      },
      "numbercomments": 0,
      "date": "5 months ago"
  },
  {
      "username": "Up_to_the_top",
      "ubication": "Los Angeles, California",
      "profilepic": "<img src=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQTQZl5WBlexuVj_oYVHugXlKk8GbVnbSMEyg&usqp=CAU>",
      "post": "<img src=https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2fwW13I6iqEDlC07L5OO7GZm8VZ8ORhuDxg&usqp=CAU>",
      "likes": 421,
      "caption": {
          "usercomment": "New protein shake, buy now for $99.99. Join our team now!",
          "hashtag": "#buy #joinus #natural"
      },
      "numbercomments": 190,
      "date": "2 days ago"
  },
  {
      "username": "NotABot",
      "ubication": "Silicon Valley",
      "profilepic": "<img src=https://d39bmof8blmz8u.cloudfront.net/wp-content/uploads/2022/05/cuantos-bots-tiene-twitter.png>",
      "post": "<img src=https://kom-agency.com/wp-content/uploads/2019/04/foto_0000001120170808101913.jpg>",
      "likes": 421,
      "caption": {
          "usercomment": "Next stop on our journey!",
          "hashtag": "#siliconvalley #totallyahuman"
      },
      "numbercomments": 100,
      "date": "3 Jan 2020"
  }
]
export default data;