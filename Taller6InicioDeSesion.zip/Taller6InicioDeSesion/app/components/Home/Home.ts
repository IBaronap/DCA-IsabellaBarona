import data from "./Feed/data.js"

import "./Feed/components/index.js"
import MyStories, {SAttribute} from "./Feed/components/stories/Stories.js";
import MyCounter from "./Feed/components/Counter/Counter.js";
import MyProfile, {Attribute} from "./Feed/components/Profile/Profile.js";
import MyRecomend, {SBAttribute} from "./Feed/components/Sidebar/Sidebar.js";


class FeedContainer extends HTMLElement{
    counters: MyCounter[] = [];
    profiles: MyProfile[] =[];

    constructor(){
        super();
        this.attachShadow({mode: "open"});
        const counter = this.ownerDocument.createElement("my-counter") as MyCounter;
        counter.button.addEventListener("click",()=>{
            console.log("button clicked");
        })
        this.counters.push(counter);

        data.forEach((user)=>{
            const profileCard = this.ownerDocument.createElement("my-profile") as MyProfile;
            profileCard.setAttribute(Attribute.username, user.username);
            profileCard.setAttribute(Attribute.ubication, user.ubication);
            profileCard.setAttribute(Attribute.profilepic, user.profilepic);
            profileCard.setAttribute(Attribute.post, user.post);
            profileCard.setAttribute(Attribute.usercomment, user.caption.usercomment);
            profileCard.setAttribute(Attribute.hashtag, user.caption.hashtag);
            profileCard.setAttribute(Attribute.numbercomments, String(user.numbercomments));
            profileCard.setAttribute(Attribute.date, user.date);
            this.profiles.push(profileCard);
        });
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if(this.shadowRoot){
            this.shadowRoot.innerHTML = ``;
            this.profiles.forEach((profile)=>{
                this.shadowRoot?.appendChild(profile);
            })
        }
    }
}

class StoriesContainer extends HTMLElement{
    stories: MyStories[] =[];

    constructor(){
        super();
        this.attachShadow({mode: "open"});

        data.forEach((user)=>{
            const storyCard = this.ownerDocument.createElement("my-stories") as MyStories;
            storyCard.setAttribute(SAttribute.username, user.username);
            storyCard.setAttribute(SAttribute.profilepic, user.profilepic);
            this.stories.push(storyCard);
        });
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if(this.shadowRoot){
            this.shadowRoot.innerHTML = ``;
            this.stories.forEach((story)=>{
                this.shadowRoot?.appendChild(story);
            })
        }
    }
}

class Recomendation extends HTMLElement{
    recomendations: MyRecomend[] =[];

    constructor(){
        super();
        this.attachShadow({mode: "open"});

        data.forEach((user)=>{
            const storyCard = this.ownerDocument.createElement("my-sidebar") as MyRecomend;
            storyCard.setAttribute(SBAttribute.username, user.username);
            storyCard.setAttribute(SBAttribute.profilepic, user.profilepic);
            this.recomendations.push(storyCard);
        });
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if(this.shadowRoot){
            this.shadowRoot.innerHTML = ``;
            this.recomendations.forEach((recomendation)=>{
                this.shadowRoot?.appendChild(recomendation);
            })
        }
    }
}

customElements.define("stories-container",StoriesContainer);

customElements.define("feed-container",FeedContainer);

customElements.define("recomend-container",Recomendation);


export class Home extends HTMLElement{
    
    constructor(){
        super();
        this.attachShadow({mode: "open"});
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if(!this.shadowRoot) return;
        this.shadowRoot.innerHTML = `<link href="./components/Home/style.css" rel="stylesheet">
        <article>
        <link href="./components/Home/style.css" rel="stylesheet">
        <div class="Head">
        <img class="Logo" src="./components/Home/Feed/components/Profile/Imgs/Logo.png">
        <input type="text" class="search" placeholder="Search">
        <div class="icons">
            <img class="HeadIcon" src="./components/Home/Feed/components/Profile/Imgs/Home.png">
            <img class="HeadIcon" src="./components/Home/Feed/components/Profile/Imgs/Chat.jpg">
            <img class="HeadIcon" src="./components/Home/Feed/components/Profile/Imgs/Upload.png">
            <img class="HeadIcon" src="./components/Home/Feed/components/Profile/Imgs/Explore.png">
            <img class="HeadIcon" src="./components/Home/Feed/components/Profile/Imgs/heart.png">
            <img class="HeadIcon" id="UserPic" src="https://i.pinimg.com/originals/49/88/21/498821435726040a731f849a8c9d9244.png">    
        </div>
    </div>
    <div class="content">
        <div>
            <div class="stories">
                <stories-container></stories-container>
            </div>
            <feed-container></feed-container>
        </div>
        <div class="Sidebar">
            <div class="user">
                <img class="Prof" src="https://i.pinimg.com/originals/49/88/21/498821435726040a731f849a8c9d9244.png">
                <div>
                    <p class="A">Skeleton666</p>
                    <p class="B">Skeleton666</p>
                </div>
                <p class="switch">Switch</p>
            </div>
            <div class="Suggestions">
                <p class="Suggest">Suggestions for you</p>
                <p class="SeeAll">See All</p>
            </div>
            <recomend-container></recomend-container>
            <p class="About">About · Help · Press · API · Jobs · Privacy · Terms · Locations · Top Accounts · Hashtags · Language</p>
            <p class="About">2022 INSTAGRAM BUT NOT FROM META</p>
        </div>
        
    </div>
        </article>
        `
    }
}

customElements.define("app-home",Home);